Project #3: Allocator
Date: Wed, 10 Oct 2012

Course Name: cs371p
Unique: 53060

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail.com
Estimated number of hours: 20
Actual    number of hours: 13

Partner First Name: Jacob
Partner Last Name: Wilke
Partner EID: jlw3599
Partner E-mail: jake.wilke@gmail.com
Partner Estimated number of hours: 21
Partner Actual    number of hours: 13

Turnin CS Username: keo
GitHub ID: kieldro
GitHub Repository Name: cs371p

Comments:
The test suite tests possible edge cases (specifically test 7 and 8).  We wanted to test with other
classes of different size but some of the tests (specifically, the ones created for us) used int
values for the construct methods and therefore wouldn't work for user-made classes.  However,
we did create an Elephant class that was 5 bytes in size and tested it on the edge case tests as well as
other tests that didn't try to construct with an int value and it also passed all the tests.

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
