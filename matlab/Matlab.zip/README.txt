Project #4: Matlab
Date: Wed, 24 Oct 2012

Course Name: cs371p
Unique: 53060

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail.com
Estimated number of hours: 20
Actual    number of hours: 20

Partner First Name: Fayz
Partner Last Name: Rahman
Partner EID: fnr75
Partner E-mail: fayz.rahman@utexas.edu
Partner Estimated number of hours: 15
Partner Actual    number of hours: 20

Turnin CS Username: keo
GitHub ID: kieldro
GitHub Repository Name: cs371p

Comments:
Run using -std=c++0x as on the Makefile on my repo

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
