Project #2: Voting
Date: Wed, 26 Sep 2012

Course Name: cs371p
Unique: 53060

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail
Estimated number of hours: 10
Actual    number of hours: 18
11:20a - 11:40
11:10a - 4p
10:30a - 8p
4:30p - 8p

Turnin CS Username: keo
GitHub ID: kieldro
GitHub Repository Name: cs371p

Comments:

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
