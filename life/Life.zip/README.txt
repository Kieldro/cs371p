Project #5: Life
Date: Wed, 28 Nov 2012

Course Name: cs371p
Unique: 53060

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail.com
Estimated number of hours: 20
Actual    number of hours: 15
4 hrs: 9p - 1a
5 hrs: 1130a - 4:30
4.5 hrs: 12p - 4:30
1 hrs: 7p - 8p
0 hrs: 11a - 

Partner First Name: Graham
Partner Last Name: Benevelli
Partner EID: grambo
Partner E-mail: grahambenevelli@gmail.com
Partner Estimated: 20
Partner Actual   : -1

Turnin CS Username: keo
GitHub ID: kieldro
GitHub Repository Name: cs371p

Comments:
link to the UML: http://www.gliffy.com/pubdoc/4058932/L.png

-2d vector of Cell or Cell*?

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
