
#ifndef Cell_h
#define Cell_h

#include "AbstractCell.h"

class Cell : public AbstractCell{
	public:
	AbstractCell cell;
	int age;
	
	int update(int neighbors){
			return cell.update(neighbors);
	}
		
	bool readChar(char c) {
		return cell.readChar(c);
	}
	
	bool isAlive() {
		return cell.isAlive();	
	}
	
	void ageCell(int inc) {
		cell.ageCell(inc);	
	}
	
	friend ostream& operator<< (ostream &strm, const Cell& c){
			if (c.age < 0)
				return strm << "-";
			if (c.age < 10)
				return strm << c.age;
			return strm << "+";
		}
	
};
#endif // Cell_h