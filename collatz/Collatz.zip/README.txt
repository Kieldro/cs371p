Project #1: Collatz
Date: Wed, 12 Sep 2012

Course Name: cs371p
Unique: 53060

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail
Estimated number of hours: 6
Actual number of hours: .5
7:30p - 8p
11:30 - 12
2:30p - 3p
11:30a - 2p

Turnin CS Username: keo
GitHub ID: kieldro
GitHub Repository Name: cs371p

Comments:
-compiling unittests also causes source file to be compiled, why?
-why is it dangerous to compare signed and unsigned?

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
