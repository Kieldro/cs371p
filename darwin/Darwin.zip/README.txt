Project #5: Darwin
Date: Wed, 7 Nov 2012

Course Name: cs371p
Unique: 53060

First Name: Ian
Last Name: Buitrago
EID: ib
E-mail: kieldro@gmail.com
Estimated number of hours: 20
Actual    number of hours: 17
1 5:30p - 630
2 1p - 3p
4 6:40p - 11p
4 11:40a - 12:40p 6:30p - 9:30p
2 1p - 3p

Partner First Name: Jonathan
Partner Last Name: Chen
Partner EID: JC
Partner E-mail: jontitan@gmail.com
Partner Estimated number of hours: 20
Partner Actual    number of hours: 14

Turnin CS Username: keo
GitHub ID: kieldro
GitHub Repository Name: cs371p

Comments:
best creature kills the rover.
advantages of pointers?
calls using default parameter must be defined after the function.

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
